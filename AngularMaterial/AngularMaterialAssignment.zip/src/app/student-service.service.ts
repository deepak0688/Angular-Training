import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Student } from 'src/model/student';

@Injectable({
  providedIn: 'root'
})

export class StudentServiceService {
  constructor(public http:HttpClient) { }
  url:string="http://localhost:3000";
  
  studentSave(stud:Student)
  {
      return this.http.post<Student>(this.url+"/saveStudent",stud);
  }
}
