import { Component, OnInit, Input } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { FormBuilder, FormGroup, Validators, FormsModule, FormControl} from '@angular/forms';
import { Employee } from "src/app/model/employee";
import { CommonserviceService } from "src/app/commonservice.service";

@Component({
  selector: "app-employee",
  templateUrl: "./employee.component.html",
  styleUrls: ["./employee.component.css"],
})

export class EmployeeComponent implements OnInit {

  public data;  
  constructor(private fb:FormBuilder, public s: CommonserviceService, private router: Router, private route: ActivatedRoute) {
    this.data = s.getOption();  
  }
  
  emp = new Employee();
  id: number;
  e: Employee;
  employeeForm!:FormGroup;
  submitted = false;
  namepattern!:"^[a-zA-Z ]{2,20}$";
  
  ngOnInit(): void {
   
    this.employeeForm=new FormGroup({
      id: new FormControl(''),
      name: new FormControl('',[Validators.required,Validators.pattern(this.namepattern)]),
      address: new FormControl('',[Validators.required]),
      mobno: new FormControl('',[Validators.required,Validators.minLength(10),Validators.maxLength(10), Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")])
   
    })
}

  allowNumericDigitsOnlyOnKeyUp(evt) {		
		evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
	}

  onSubmit() {
    this.submitted = true;
    if(this.employeeForm.valid)
      {
        if(this.employeeForm.value.id == undefined)
        {
          this.s.employeeSave(this.employeeForm.value).subscribe();
        }
        else
        {
          this.s.employeeUpdateData(this.employeeForm.value).subscribe();
        }
        window.location.reload();
      }
  }

  reset() {
    this.employeeForm.clearValidators()
    this.employeeForm.reset();
  }

  reload() {
    let currentUrl = this.router.url;

    this.router.routeReuseStrategy.shouldReuseRoute = () => false;

    this.router.onSameUrlNavigation = "reload";

    this.router.navigate([currentUrl]);
  }

}
