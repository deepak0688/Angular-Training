import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

interface IUser {
  projectname: string;
  projectstatus: string;
  emailid: string;
}

@Component({
  selector: 'app-reactive-forms',
  templateUrl: './reactive-forms.component.html',
  styleUrls: ['./reactive-forms.component.css']
})
export class ReactiveFormsComponent implements OnInit {

  submittedValues: {};
  isSubmitted = false;
  reactiveForm!: FormGroup;
  user: IUser;
  emailpattern!:"^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
  ProjectStatus: string[] = [
    'Stable','Critical','Finished'
  ];

  constructor(private fb:FormBuilder) {
    this.user = {} as IUser;
  }

  ngOnInit(): void {
    this.reactiveForm = this.fb.group({
      projectname: ['', Validators.required],
      projectstatus: ['', Validators.required],
      emailid: ['', Validators.compose([Validators.required, Validators.pattern(this.emailpattern)])],
    });
  }

  public submitData(form): void {
    if (this.reactiveForm.invalid) {
           return;
    }

    if(form.value.projectname == 'test' || form.value.projectname == 'Test' || form.value.projectname == 'TEST')
    {
      alert("Project name cannot be Test");
      //return;
    }
    else
    {
      this.submittedValues = form.value;
    }
    return;
  }
}