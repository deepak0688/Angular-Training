import { Component, Input, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormBuilder, FormGroup, Validators, FormsModule} from '@angular/forms';
import { Employee } from "src/app/model/employee";
import { CommonserviceService } from "src/app/commonservice.service";

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  constructor(public s: CommonserviceService, private router: Router) {}

  employeeForm!:FormGroup;
  e: Employee[];
  empList!:Employee[]; 

  empEdit!:Employee[]; 

  ngOnInit(): void {
    
    this.s.employeeGetData().subscribe(list =>{
    this.empList=list;
    })
  }

  employeeEditData(e)
  {
    this.s.setOption('id', e.id);
    this.s.setOption('name', e.name);
    this.s.setOption('mobno',  e.mobno);
    this.s.setOption('address', e.address);
  }

  employeeDeleteData(eid)
  {
    this.s.employeeDeleteData(eid);
    window.location.reload();
  }
 
}
