export class UserForm {

    uid:number;
	emailid:string;
	subscriptions:string;
    password:string;
}