export class Employee {
    id:number;
    name:string;
    mobno:number;
    address:string;
}