
export class StudentForm {

    sid:number;
	sname:string;
	address:string;
	mobno:DoubleRange;
	email:string;
}

