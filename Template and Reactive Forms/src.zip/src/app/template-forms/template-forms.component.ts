import { Component, ViewChild, ElementRef, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { UserForm } from '../model/user';

@Component({
  selector: 'app-template-forms',
  templateUrl: './template-forms.component.html',
  styleUrls: ['./template-forms.component.css']
})
export class TemplateFormsComponent implements OnInit {

  submitted: {};
  user = new UserForm();
  Subscriptions: string[] = [
    'Basic','Advanced','Pro'
  ];
  constructor() {}
  
  ngOnInit(){}

  onSubmit(form: any) {
      this.submitted = form.value;
  }
}
