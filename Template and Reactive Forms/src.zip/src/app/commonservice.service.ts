import { Injectable } from '@angular/core';
import { Employee } from './model/employee';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonserviceService {

  constructor(public http:HttpClient) { }
  url:string="http://localhost:3000";
  
  private data = {};  
  
 setOption(option, value) {      
    this.data[option] = value;  
  }  
  
  getOption() {  
    return this.data;  
  }  

  employeeSave(emp:Employee)
  {
      return this.http.post<Employee>(this.url+"/getAllData",emp);
  }

  employeeGetData():Observable<Employee[]> 
  {
     return this.http.get<Employee[]>(this.url + "/getAllData");
  }

 employeeDeleteData(id:number)
 {
   return this.http.delete(this.url+"/getAllData/"+ id).subscribe(data => {
  });
}

 employeeUpdateData(employee: Employee): Observable<Employee> {
  return this.http.patch<Employee>(this.url+"/getAllData/"+ employee.id, employee);
 }
}
