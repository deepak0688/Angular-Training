import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Student } from 'src/model/student';
import { Registration } from 'src/model/registration';

@Injectable({
  providedIn: 'root'
})

export class StudentServiceService {
  constructor(public http:HttpClient) { }
  url:string="http://localhost:3000";
  
  studentSave(stud:Student)
  {
      return this.http.post<Student>(this.url+"/saveStudent",stud);
  }

  registrationSave(reg:Registration)
  {
      return this.http.post<Registration>(this.url+"/saveRegistration",reg);
  }
}
