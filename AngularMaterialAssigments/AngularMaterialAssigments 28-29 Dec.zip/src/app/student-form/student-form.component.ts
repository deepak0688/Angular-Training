import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { StudentServiceService } from '../student-service.service';
import { Student } from 'src/model/student';
import { DatePipe } from '@angular/common'

@Component({
  selector: 'app-student-form',
  templateUrl: './student-form.component.html',
  styleUrls: ['./student-form.component.css']
})
export class StudentFormComponent {

  stud = new Student();
  studentDetailsForm!: FormGroup;

  genders = [
    'Male',
    'Female'
  ];

  skills = [
     'Angular Basic','Angular Intermediate', 'Angular Expert'
  ];



  validation_messages = {
    'fullname': [
      { type: 'required', message: 'Full name is required' },
      { type: 'minlength', message: 'Full name must be at least 6 characters long' },
      { type: 'maxlength', message: 'Full name cannot be more than 32 characters long' }
    ],
    'gender': [
      { type: 'required', message: 'Please select your gender' }
    ],
    'dateofbirth': [
      { type: 'required', message: 'Please select your birthday' }
    ],
    'phone': [
      { type: 'required', message: 'Phone is required' },
      { type: 'minlength', message: 'Full name must be at least 6 characters long' },
      { type: 'maxlength', message: 'Full name cannot be more than 32 characters long' }
    ],
    'email': [
      { type: 'required', message: 'Email is required' },
      { type: 'pattern', message: 'Enter a valid mail' }
    ],
    'password': [
      { type: 'required', message: 'Pasword is required' },
      { type: 'minlength', message: 'Password must be at least 6 characters long' },
      { type: 'maxlength', message: 'Password cannot be more than 32 characters long' },
      { type: 'pattern', message: 'Password must containt at least one uppercase, one lowercase, and one number' }
    ]
  };

  constructor(private fb: FormBuilder, public s: StudentServiceService, public datepipe: DatePipe) { }

  ngOnInit() {
    this.createForms();
  }

  createForms() {
    // country & phone validation_messages
    let country = new FormControl(this.skills[0], Validators.required);

    // user details form validations
    this.studentDetailsForm = this.fb.group({
      fullname: new FormControl('', Validators.compose([
        Validators.maxLength(32),
        Validators.minLength(6),
        Validators.required
      ])),
      dateofbirth: ['', Validators.required],
      skills:['', Validators.required],    
      gender: new FormControl(this.genders[0], Validators.required),
      phone: ['',[Validators.required,Validators.minLength(10),Validators.maxLength(10), Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      password: new FormControl('', Validators.compose([
        Validators.minLength(6),
        Validators.maxLength(12),
        Validators.required,
        Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[a-zA-Z0-9]+$')
      ])),
      email: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ]))
    });
  }

  onSubmitStudentDetails(value) {
    if(this.studentDetailsForm.valid)
      {
        value.dateofbirth =this.datepipe.transform(value.dateofbirth, 'dd/MM/YYYY');
        this.s.studentSave(value).subscribe();
        alert('Data Saved Successfully');
        window.location.reload();
      }
  }
  }

