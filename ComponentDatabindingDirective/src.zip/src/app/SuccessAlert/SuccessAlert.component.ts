import { Component } from '@angular/core';

import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-SuccessAlert',
  templateUrl: './SuccessAlert.component.html',
  styleUrls: ['./SuccessAlert.component.css']
})
export class SuccessAlertComponent {

  Username:string="";

  isDirective=true;

  getBlueColor()
  {
    return 'blue';
  }

  getWhiteColor()
  {
    return 'white';
  }

  textClear(){
    this.Username = ' ';
  }

  isShowDiv = true;  
   
  ids:any= [ ];

  displayDiv() {  
    this.isShowDiv = !this.isShowDiv;  
    this.ids.push(this.ids.length + 1);
  }

}
