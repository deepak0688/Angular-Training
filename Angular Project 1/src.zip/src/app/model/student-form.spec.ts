import { StudentForm } from './student-form';

describe('StudentForm', () => {
  it('should create an instance', () => {
    expect(new StudentForm()).toBeTruthy();
  });
});
