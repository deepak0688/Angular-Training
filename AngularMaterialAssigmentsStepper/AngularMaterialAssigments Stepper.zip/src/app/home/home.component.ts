import { Component } from '@angular/core';
import { MaterialModule } from 'src/app/material-module'

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

}
