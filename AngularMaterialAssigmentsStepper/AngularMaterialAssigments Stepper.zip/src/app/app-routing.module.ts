import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegistrationFormComponent } from './registration-form/registration-form.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { HomeComponent } from './home/home.component';
import { CeoMessageComponent } from './ceo-message/ceo-message.component';
import { ContactDetailsComponent } from './contact-details/contact-details.component';
import { CoursesComponent } from './courses/courses.component';
import { NewcourseComponent } from './newcourse/newcourse.component';
import { StepperFormComponent } from './stepper-form/stepper-form.component';

const routes: Routes = [
    {path:"registration-form", component:RegistrationFormComponent},
    {path:"login-form", component:LoginFormComponent},
    {path:"home", component:HomeComponent},
    {path:"ceo-message", component:CeoMessageComponent},
    {path:"contact-details", component:ContactDetailsComponent},
    {path:"ceo-message", component:CeoMessageComponent},
    {path:"contact-details", component:ContactDetailsComponent},
    {path:"courses", component:CoursesComponent},
    {path:"newcourse", component:NewcourseComponent},
    {path:"stepperform", component:StepperFormComponent},
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
