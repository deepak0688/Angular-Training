import { Component } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';

@Component({
  selector: 'app-contact-details',
  templateUrl: './contact-details.component.html',
  styleUrls: ['./contact-details.component.css']
})
export class ContactDetailsComponent {

  constructor(public dialog: MatDialog) {}

  openDialog() {
    this.dialog.open(DialogExample,{
     width: '900px',
     height:'500px'
    });
   }
}

@Component({
  selector: 'DialogExample',
  templateUrl: '../ContactUs.html',
 })
 
 export class DialogExample {}
 
