import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl  } from '@angular/forms';
import { RegistrationStepper } from 'src/model/registrationStepper';
import { DatePipe } from '@angular/common'
import { Router } from '@angular/router';
import { StudentServiceService } from '../student-service.service';

@Component({
  selector: 'app-stepper-form',
  templateUrl: './stepper-form.component.html',
  styleUrls: ['./stepper-form.component.css']
})
export class StepperFormComponent {
  
  reg = new RegistrationStepper();

  Fullname:string = this.reg.Fullname!;
  EmailId:string = this.reg.EmailId!;
  FathersName:string = this.reg.FathersName!;
  MothersName:string = this.reg.MothersName!;
  Gender:string = this.reg.Gender!;
  DataofBirth:string = this.reg.DataofBirth!;
  MobileNo:string = this.reg.MobileNo!;
  FullNameBank:string = this.reg.FullNameBank!;
  BankAccountNo:string = this.reg.BankAccountNo!;
  BankName:string = this.reg.BankName!;
  IFSCCode:string = this.reg.IFSCCode!;
  InternetBanking:string = this.reg.InternetBanking!;
  MobileBanking:string = this.reg.MobileBanking!;
  PresentAddress:string = this.reg.PresentAddress!;
  PermanentAddress:string = this.reg.PermanentAddress!;
  
  
  maxChars = 60;
  genders = [
    'Male',
    'Female'
  ];

  bankingOptions = [
    'Yes',
    'No'
  ];

firstFormGroup=this.formBuilder.group({
  fullname:['', Validators.compose([
    Validators.maxLength(32),
    Validators.minLength(6),
    Validators.required
  ])],
  fathersname:['', Validators.compose([
    Validators.maxLength(32),
    Validators.minLength(6),
    Validators.required
  ])],
  mothersname:['', Validators.compose([
    Validators.maxLength(32),
    Validators.minLength(6),
    Validators.required
  ])],
  dateofbirth: ['', Validators.required],
  gender: [this.genders[0], Validators.required],
  phone: ['',Validators.compose([Validators.required,Validators.minLength(10),Validators.maxLength(10), Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")])],
  email: ['', Validators.compose([
    Validators.required,
    Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
  ])]
  })

  secondFormGroup=this.formBuilder.group({
    fullnamebank:[''],
    bankaccountno:[''],
    bankname:[''],
    ifsccode: [''],
    internetbanking: [this.bankingOptions[0]],
    mobilebanking: [this.bankingOptions[0]]
  })

  thirdFormGroup=this.formBuilder.group({
    presentaddress:['', Validators.compose([
      Validators.maxLength(60),
      Validators.required
    ])],
    permanentaddress:['', Validators.compose([
      Validators.maxLength(60),
      Validators.required
    ])],
    })

  constructor(private formBuilder:FormBuilder, public s: StudentServiceService, public datepipe: DatePipe, private router: Router){
  }

  firstform_validation_messages = {
    'fullname': [
      { type: 'required', message: 'Full name is required' },
      { type: 'minlength', message: 'Full name must be at least 6 characters long' },
      { type: 'maxlength', message: 'Full name cannot be more than 32 characters long' }
    ],
    'fathersname': [
      { type: 'required', message: 'Full name is required' },
      { type: 'minlength', message: 'Full name must be at least 6 characters long' },
      { type: 'maxlength', message: 'Full name cannot be more than 32 characters long' }
    ],
    'mothersname': [
      { type: 'required', message: 'Full name is required' },
      { type: 'minlength', message: 'Full name must be at least 6 characters long' },
      { type: 'maxlength', message: 'Full name cannot be more than 32 characters long' }
    ],
    'gender': [
      { type: 'required', message: 'Please select your gender' }
    ],
    'dateofbirth': [
      { type: 'required', message: 'Please select your birthday' }
    ],
    'phone': [
      { type: 'required', message: 'Mobile no is required' },
      { type: 'maxlength', message: 'Mobile no should be 10 digits long' }
    ],
    'email': [
      { type: 'required', message: 'Email is required' },
      { type: 'pattern', message: 'Enter a valid mail' }
    ],
    'presentaddress': [
      { type: 'required', message: 'Present address is required' },
      { type: 'maxlength', message: 'Full name cannot be more than 60 characters long' }
    ],
    'permanentaddress': [
      { type: 'required', message: 'Permanent address is required' },
      { type: 'maxlength', message: 'Full name cannot be more than 60 characters long' }
    ],
  };

  onSubmitRegDetails(form1value, form2value, form3value) {
  if(this.firstFormGroup.valid && this.thirdFormGroup.valid)
    {
      // value.dateofbirth =this.datepipe.transform(value.dateofbirth, 'dd/MM/YYYY');
      // this.s.stepperRegistrationSave(value).subscribe();
      // alert('Data Saved Successfully');
      // window.location.reload();
      
      this.reg.Fullname = form1value.fullname;
      this.reg.EmailId = form1value.email;
      this.reg.FathersName = form1value.fathersname;
      this.reg.MothersName = form1value.mothersname;
      this.reg.Gender = form1value.gender;
      this.reg.DataofBirth = form1value.dateofbirth;
      this.reg.MobileNo = form1value.phone;
      this.reg.FullNameBank = form2value.fullnamebank;
      this.reg.BankAccountNo = form2value.bankaccountno;
      this.reg.BankName = form2value.bankname;
      this.reg.IFSCCode = form2value.ifsccode;
      this.reg.InternetBanking = form2value.internetbanking;
      this.reg.MobileBanking = form2value.mobilebanking;
      this.reg.PresentAddress = form3value.presentaddress;
      this.reg.PermanentAddress = form3value.permanentaddress;

      this.s.stepperRegistrationSave(this.reg).subscribe();
      alert('Data Saved Successfully');
      window.location.reload();

    }
}
}
