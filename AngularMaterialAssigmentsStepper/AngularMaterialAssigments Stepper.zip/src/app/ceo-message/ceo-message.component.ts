import { Component } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';

@Component({
  selector: 'app-ceo-message',
  templateUrl: './ceo-message.component.html',
  styleUrls: ['./ceo-message.component.css']
})
export class CeoMessageComponent {

  constructor(public dialog: MatDialog) {}

  openDialog() {
    this.dialog.open(DialogExample,{
     width: '700px',
     height:'350px'
    });
   }
}

@Component({
  selector: 'DialogExample',
  templateUrl: '../CEOMessage.html',
 })
 
 export class DialogExample {}
 
