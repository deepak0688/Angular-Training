import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent, } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatButtonModule} from '@angular/material/button';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {ReactiveFormsModule, FormsModule } from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import { StudentFormComponent } from './student-form/student-form.component'
import {MatSelectModule} from '@angular/material/select';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatNativeDateModule} from '@angular/material/core';
import {MatRadioModule} from '@angular/material/radio';
import { DatePipe } from '@angular/common'
import { HttpClientModule } from '@angular/common/http';
import { MaterialModule } from './material-module';
import { NavbarModule } from './navbar-module';
import { LoginFormComponent } from './login-form/login-form.component'
import { Router, RouterModule, Routes } from '@angular/router';
import { RegistrationFormComponent } from './registration-form/registration-form.component';
import { HomeComponent } from './home/home.component';
import { NavbarComponent } from './navbar/navbar.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { CeoMessageComponent, DialogExample } from './ceo-message/ceo-message.component';
import { ContactDetailsComponent } from './contact-details/contact-details.component';
import { CoursesComponent } from './courses/courses.component';
import { NewcourseComponent } from './newcourse/newcourse.component';
import { StepperFormComponent } from './stepper-form/stepper-form.component';

@NgModule({
  declarations: [
    AppComponent,
    StudentFormComponent,
    LoginFormComponent,
    RegistrationFormComponent,
    HomeComponent,
    NavbarComponent,
    AboutusComponent,
    CeoMessageComponent,
    ContactDetailsComponent,
    CoursesComponent,
    NewcourseComponent,
    StepperFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCheckboxModule,
    MatIconModule,
    MatSelectModule,
    MatDatepickerModule, 
    MatNativeDateModule,
    MatRadioModule,
    MatInputModule,
    HttpClientModule,
    MaterialModule,
    NavbarModule,
    RouterModule,
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }