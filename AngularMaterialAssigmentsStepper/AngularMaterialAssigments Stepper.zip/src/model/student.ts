export class Student {
    id:number;
    Fullname:string;
    EmailId:string;
    Password:string;
    Gender:string;
    DataofBirth:string;
    MobileNo:number;
    Skills:string;
}