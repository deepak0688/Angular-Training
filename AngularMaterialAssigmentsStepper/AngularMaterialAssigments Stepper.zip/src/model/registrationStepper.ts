export class RegistrationStepper {
    id:number;
    Fullname:string;
    EmailId:string;
    FathersName:string;
    MothersName:string;
    Gender:string;
    DataofBirth:string;
    MobileNo:string;
    FullNameBank:string;
    BankAccountNo:string;
    BankName:string;
    IFSCCode:string;
    InternetBanking:string;
    MobileBanking:string;
    PresentAddress:string;
    PermanentAddress:string;
}